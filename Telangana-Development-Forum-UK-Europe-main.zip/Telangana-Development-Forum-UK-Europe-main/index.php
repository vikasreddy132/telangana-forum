﻿<?php include "includes/header.php" ?>

        
        <!--Main Slider Start-->
        <section class="main-slider-three clearfix" id="home">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{
                "slidesPerView": 1,
                "loop": true,
                "effect": "cards",
                "cardsEffect": {
                    "perSlideOffset": 8,
                    "perSlideRotate": 2,
                    "slideShadows": true
                },
                "pagination": {
                    "el": "#main-slider-pagination",
                    "type": "bullets",
                    "clickable": true
                },
                "navigation": {
                    "nextEl": "#main-slider__swiper-button-next",
                    "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                    "delay": 5000
                }
            }'>
                <div class="swiper-wrapper">

                    <div class="swiper-slide">
                        <div class="image-layer-three" style="background-image: url(assets/images/backgrounds/1.svg);">
                        </div>
                        <!-- /.image-layer -->
                        <div class="main-slider-three-shape"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-7 col-lg-8">
                                    <div class="main-slider-three__content">
                                        <p class="main-slider-three__sub-title">Ultimate Crowdfunding Platform</p>
                                        <h2 class="main-slider-three__title">Change the way <br>
                                            art is valued</h2>
                                        <p class="main-slider-three__text">Qrowd is where early adopters and innovation
                                            seekers find lively, <br>
                                            imaginative tech before it hits the mainstream.</p>
                                        <div class="main-slider-three__btn-box">
                                            <a href="project-details.html" class="thm-btn main-slider__btn"> Start a
                                                Project</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="image-layer-three" style="background-image: url(assets/images/backgrounds/2.svg);">
                        </div>
                        <!-- /.image-layer -->
                        <div class="main-slider-three-shape"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-7 col-lg-8">
                                    <div class="main-slider-three__content">
                                        <p class="main-slider-three__sub-title">Ultimate Crowdfunding Platform</p>
                                        <h2 class="main-slider-three__title">Change the way <br>
                                            art is valued</h2>
                                        <p class="main-slider-three__text">Qrowd is where early adopters and innovation
                                            seekers find lively, <br>
                                            imaginative tech before it hits the mainstream.</p>
                                        <div class="main-slider-three__btn-box">
                                            <a href="project-details.html" class="thm-btn main-slider__btn"> Start a
                                                Project</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="image-layer-three" style="background-image: url(assets/images/backgrounds/3.svg);">
                        </div>
                        <!-- /.image-layer -->
                        <div class="main-slider-three-shape"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-7 col-lg-8">
                                    <div class="main-slider-three__content">
                                        <p class="main-slider-three__sub-title">Ultimate Crowdfunding Platform</p>
                                        <h2 class="main-slider-three__title">Change the way <br>
                                            art is valued</h2>
                                        <p class="main-slider-three__text">Qrowd is where early adopters and innovation
                                            seekers find lively, <br>
                                            imaginative tech before it hits the mainstream.</p>
                                        <div class="main-slider-three__btn-box">
                                            <a href="project-details.html" class="thm-btn main-slider__btn"> Start a
                                                Project</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

                <!-- If we need navigation buttons -->
                <div class="main-slider__nav">
                    <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i class="icon-right-arrow"></i>
                    </div>
                    <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i class="icon-right-arrow"></i>
                    </div>
                </div>

            </div>
        </section>
        <!--Main Slider End-->

        <!--Welcome One Start-->
        <section class="welcome-one" id="about">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="welcome-one__left wow slideInLeft" data-wow-delay="100ms"
                            data-wow-duration="2500ms">
                            <div class="welcome-one__img-one">
                                <img src="assets/images/landingpage/about-1.svg" alt="">
                            </div>
                            <div class="welcome-one__img-two">
                                <img src="assets/images/landingpage/about-2.svg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="welcome-one__right">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">About</span>
                                <h2 class="section-title__title">Telangana Development
                                    Forum UK Europe</h2>
                            </div>
                            <h3 class="welcome-one__sub-title">About Telangana–
                                The 29th state of Indian union.</h3>
                            <p class="welcome-one__text">Telangana is a state in south central India, constituting most
                                of the Deccan plateau. Centuries of independent existence has given Telangana its
                                distinctive and rich culture and identity. This region is rich in natural resources with
                                vast stretches of forests, rich mineral resources and great rivers.</p>
                            <ul class="welcome-one__points list-unstyled">
                                <li>
                                    <div class="icon">
                                        <span class="icon-success"></span>
                                    </div>
                                    <div class="content">
                                        <h3>Highest Success Rates</h3>
                                        <p>Magna aliqa enim sed ipsum nisi ainy veniam quis</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="icon-money-bag"></span>
                                    </div>
                                    <div class="content">
                                        <h3>Millions in Funding</h3>
                                        <p>Lorem ipsum dolor sit ametys consectet elit</p>
                                    </div>
                                </li>
                            </ul>
                            <div class="welcomw-one__bottom">
                                <a href="about.html" class="thm-btn">Discover More</a>
                                <a href="team.html" class="welcome-one__expert">Speak with Expert</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Welcome One End-->
        <section class="ready-two">
            <div class="ready-two-shape-1 float-bob-x">
                <img src="assets/images/shapes/ready-two-shape-1.png" alt="">
            </div>
            <div class="container">
                <div class="ready-two__inner">
                    <div class="ready-two__big-icon float-bob-y-2">
                        <span class="icon-fundraiser"></span>
                    </div>
                    <div class="ready-two__left">
                        <div class="ready-two__icon">
                            <span class="icon-fundraiser"></span>
                        </div>
                        <div class="ready-two__content">
                            <p>Lorem ipsum dolor sit amet.</p>
                            <h3>Lorem ipsum dolor, sit amet consectetur</h3>
                        </div>
                    </div>
                    <div class="ready-two__right">
                        <a href="#" class="thm-btn ready-two__btn">Please Donate</a>
                    </div>
                </div>
            </div>
        </section>


        <!--Project Three Start-->
        <section class="project-three" id="events">
            <div class="container">
                <div class="project-three__top">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <div class="project-three__top-left">
                                <div class="section-title text-left">
                                    <span class="section-title__tagline">We connects nonprofits, donors, and companies
                                        in nearly every country around the world.
                                    </span>
                                    <h2 class="section-title__title">Kshara Jyothi Charity Events</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="project-three__top-right">
                                <ul class="project-three__filter style1 post-filter list-unstyled clearfix">
                                    <li data-filter=".filter-item" class="active"><span class="filter-text">All
                                            Category</span>
                                    </li>
                                    <li data-filter=".helth"><span class="filter-text">Helth & Diseases</span></li>
                                    <li data-filter=".edu"><span class="filter-text">Education</span></li>
                                    <li data-filter=".hunger"><span class="filter-text">Hunger & Nutrition</span></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="project-three__bottom">
                    <div class="row filter-layout masonary-layout">
                        <!--Project One Single Start-->
                        <div class="col-xl-4 col-lg-6 col-md-6 filter-item  helth">
                            <div class="project-one__single">
                                <div class="project-one__img-box">
                                    <div class="project-one__img">
                                        <img src="assets/images/project/1.svg" alt="">
                                    </div>
                                    <div class="project-one__icon">
                                        <i class="far fa-heart"></i>
                                    </div>
                                </div>
                                <div class="project-one__content">
                                    <div class="project-one__tag">
                                        <p>Helth & Diseases</p>
                                    </div>
                                    <h3 class="project-one__title"><a href="project-details.html">Donation for helpless
                                            people</a></h3>
                                    <div class="project-one__remaing">
                                        <div class="text">
                                            <p>Obligations of business it will frequently have to repudiated.</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--Project One Single End-->


                        <!--Project One Single Start-->
                        <div class="col-xl-4 col-lg-6 col-md-6 filter-item  helth">
                            <div class="project-one__single">
                                <div class="project-one__img-box">
                                    <div class="project-one__img">
                                        <img src="assets/images/project/3.svg" alt="">
                                    </div>
                                    <div class="project-one__icon">
                                        <i class="far fa-heart"></i>
                                    </div>
                                </div>
                                <div class="project-one__content">
                                    <div class="project-one__tag">
                                        <p>Helth & Diseases</p>
                                    </div>
                                    <h3 class="project-one__title"><a href="project-details.html">Donation for helpless
                                            people</a></h3>
                                    <div class="project-one__remaing">
                                        <div class="text">
                                            <p>Obligations of business it will frequently have to repudiated.</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--Project One Single End-->


                        <!--Project One Single Start-->
                        <div class="col-xl-4 col-lg-6 col-md-6 filter-item  edu">
                            <div class="project-one__single">
                                <div class="project-one__img-box">
                                    <div class="project-one__img">
                                        <img src="assets/images/project/2.svg" alt="">
                                    </div>
                                    <div class="project-one__icon">
                                        <i class="far fa-heart"></i>
                                    </div>
                                </div>
                                <div class="project-one__content">
                                    <div class="project-one__tag">
                                        <p>Education</p>
                                    </div>
                                    <h3 class="project-one__title"><a href="project-details.html">Bourne – Travel
                                            Help girls education</a></h3>
                                    <div class="project-one__remaing">
                                        <div class="text">
                                            <p>Indignation and dislike men who are like beguiled and demoralized.</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--Project One Single End-->
                        <!--Project One Single Start-->
                        <div class="col-xl-4 col-lg-6 col-md-6 filter-item  edu">
                            <div class="project-one__single">
                                <div class="project-one__img-box">
                                    <div class="project-one__img">
                                        <img src="assets/images/project/4.svg" alt="">
                                    </div>
                                    <div class="project-one__icon">
                                        <i class="far fa-heart"></i>
                                    </div>
                                </div>
                                <div class="project-one__content">
                                    <div class="project-one__tag">
                                        <p>Education</p>
                                    </div>
                                    <h3 class="project-one__title"><a href="project-details.html">Bourne – Travel
                                            Help girls education</a></h3>
                                    <div class="project-one__remaing">
                                        <div class="text">
                                            <p>Our power of choice is untrammelled and nothing prevents like best.</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--Project One Single End-->



                        <!--Project One Single Start-->
                        <div class="col-xl-4 col-lg-6 col-md-6 filter-item  hunger">
                            <div class="project-one__single">
                                <div class="project-one__img-box">
                                    <div class="project-one__img">
                                        <img src="assets/images/project/5.svg" alt="">
                                    </div>
                                    <div class="project-one__icon">
                                        <i class="far fa-heart"></i>
                                    </div>
                                </div>
                                <div class="project-one__content">
                                    <div class="project-one__tag">
                                        <p>Hunger & Nutrition</p>
                                    </div>
                                    <h3 class="project-one__title"><a href="project-details.html">Bourne – Travel
                                            Help girls education</a></h3>
                                    <div class="project-one__remaing">
                                        <div class="text">
                                            <p>Our power of choice is untrammelled and nothing prevents like best.</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--Project One Single Start-->
                        <div class="col-xl-4 col-lg-6 col-md-6 filter-item  hunger">
                            <div class="project-one__single">
                                <div class="project-one__img-box">
                                    <div class="project-one__img">
                                        <img src="assets/images/project/6.svg" alt="">
                                    </div>
                                    <div class="project-one__icon">
                                        <i class="far fa-heart"></i>
                                    </div>
                                </div>
                                <div class="project-one__content">
                                    <div class="project-one__tag">
                                        <p>Hunger & Nutrition</p>
                                    </div>
                                    <h3 class="project-one__title"><a href="project-details.html">Bourne – Travel
                                            Help girls education</a></h3>
                                    <div class="project-one__remaing">
                                        <div class="text">
                                            <p>Our power of choice is untrammelled and nothing prevents like best.</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>



                    </div>
                </div>
            </div>
        </section>
        <!--Project Three End-->
        <!--Brand One Start-->
        <section class="brand-two">
            <div class="container">
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100, "slidesPerView": 5, "autoplay": { "delay": 5000 }, "breakpoints": {
                    "0": {
                        "spaceBetween": 30,
                        "slidesPerView": 2
                    },
                    "375": {
                        "spaceBetween": 30,
                        "slidesPerView": 2
                    },
                    "575": {
                        "spaceBetween": 30,
                        "slidesPerView": 3
                    },
                    "767": {
                        "spaceBetween": 50,
                        "slidesPerView": 4
                    },
                    "991": {
                        "spaceBetween": 50,
                        "slidesPerView": 5
                    },
                    "1199": {
                        "spaceBetween": 100,
                        "slidesPerView": 5
                    }
                }}'>
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="assets/images/brand/1.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/2.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/3.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/4.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/5.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/1.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/6.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/7.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/2.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/3.png" alt="">
                        </div><!-- /.swiper-slide -->
                    </div>
                </div>
            </div>
        </section>
        <!--Brand One End-->

        <!--Team Page Start-->
        <section class="team-carousel-page">
            <div class="container">

                <div class="section-title text-center">
                    <span class="section-title__tagline">Our work would not be possible without the work of our
                        dedicated volunteers.</span>
                    <h3 class="section-title__title">Our Team</h2>
                </div>

                <div class="team-carousel thm-owl__carousel owl-theme owl-carousel carousel-dot-style" data-owl-options='{
        "items": 4,
        "margin": 30,
        "smartSpeed": 700,
        "loop":true,
        "autoplay": 6000,
        "nav":false,
        "dots":true,
        "navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
        "responsive":{
            "0":{
                "items":1
            },
            "768":{
                "items":2
            },
            "992":{
                "items": 4
            }
        }
    }'>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Mike Hardson</a></h3>
                                <p class="team-one__sub-title">Consultant</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Sarah Albert</a></h3>
                                <p class="team-one__sub-title">Manager</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Kevin Martin</a></h3>
                                <p class="team-one__sub-title">Director</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Aleesha Brown</a></h3>
                                <p class="team-one__sub-title">Consultant</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Michale Smith</a></h3>
                                <p class="team-one__sub-title">Consultant</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Jessica Rose</a></h3>
                                <p class="team-one__sub-title">Director</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Mike Hardson</a></h3>
                                <p class="team-one__sub-title">Consultant</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Sarah Albert</a></h3>
                                <p class="team-one__sub-title">Manager</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                    <div class="item">
                        <!--Team One Single Start-->
                        <div class="team-one__single">
                            <div class="team-one__img">
                                <img src="assets/images/team/1.png" alt="">
                            </div>
                            <div class="team-one__content">
                                <h3 class="team-one__name"><a href="team.html">Kevin Martin</a></h3>
                                <p class="team-one__sub-title">Director</p>
                                <div class="team-one__social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                        <!--Team One Single End-->
                    </div>
                </div>
            </div>
        </section>
        <!--Team Page End-->
        <!--Testimonial Two Start-->
        <section class="testimonial-two" id="testimonials">
            <div class="testimonial-two-bg"
                style="background-image: url(assets/images/backgrounds/testimonial-two-bg.png);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-4">
                        <div class="testimonial-two__left">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">Our Testimonials</span>
                                <h2 class="section-title__title">Why people love us</h2>
                            </div>
                            <p class="testimonial-two__text">Please read below to see what a few of our charity partners
                                have to say about us.
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-8">
                        <div class="testimonial-two__right">
                            <div class="testimonial-two__carousel owl-carousel owl-theme thm-owl__carousel"
                                data-owl-options='{
                                "loop": true,
                                "autoplay": true,
                                "margin": 30,
                                "nav": true,
                                "dots": false,
                                "smartSpeed": 500,
                                "autoplayTimeout": 10000,
                                "navText": ["<span class=\"icon-right-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
                                "responsive": {
                                    "0": {
                                        "items": 1
                                    },
                                    "768": {
                                        "items": 2
                                    },
                                    "992": {
                                        "items": 2
                                    },
                                    "1200": {
                                        "items": 2
                                    }
                                }
                            }'>
                                <!--Testimonial Two Single Start-->
                                <div class="item">
                                    <div class="testimonial-two__single">
                                        <div class="testimonial-two__client-info">
                                            <div class="testimonial-two__client-img">
                                                <img src="assets/images/testimonial/testimonial-two-client-img-1.jpg"
                                                    alt="">
                                            </div>
                                            <div class="testimonial-two__client-content">
                                                <h4 class="testimonial-two__client-name">Sarah Albert</h4>
                                                <p class="testimonial-two__client-sub-title">CO Founder</p>
                                            </div>
                                        </div>
                                        <p class="testimonial-two__text-2">Exercitation ullamco laboris nisi ut aliquip
                                            ex ea ex commodo consequat duis aute aboris nisi ut aliquip irure
                                            reprehederit in voluptate velit esse .</p>
                                        <div class="testimonial-two__quote">
                                            <span class="icon-quotes"></span>
                                        </div>
                                        <div class="testimonial-two__rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Testimonial Two Single End-->
                                <!--Testimonial Two Single Start-->
                                <div class="item">
                                    <div class="testimonial-two__single">
                                        <div class="testimonial-two__client-info">
                                            <div class="testimonial-two__client-img">
                                                <img src="assets/images/testimonial/testimonial-two-client-img-2.jpg"
                                                    alt="">
                                            </div>
                                            <div class="testimonial-two__client-content">
                                                <h4 class="testimonial-two__client-name">Kevin Martin</h4>
                                                <p class="testimonial-two__client-sub-title">CO Founder</p>
                                            </div>
                                        </div>
                                        <p class="testimonial-two__text-2">Exercitation ullamco laboris nisi ut aliquip
                                            ex ea ex commodo consequat duis aute aboris nisi ut aliquip irure
                                            reprehederit in voluptate velit esse .</p>
                                        <div class="testimonial-two__quote">
                                            <span class="icon-quotes"></span>
                                        </div>
                                        <div class="testimonial-two__rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Testimonial Two Single End-->
                                <!--Testimonial Two Single Start-->
                                <div class="item">
                                    <div class="testimonial-two__single">
                                        <div class="testimonial-two__client-info">
                                            <div class="testimonial-two__client-img">
                                                <img src="assets/images/testimonial/testimonial-two-client-img-3.jpg"
                                                    alt="">
                                            </div>
                                            <div class="testimonial-two__client-content">
                                                <h4 class="testimonial-two__client-name">Kevin Coper</h4>
                                                <p class="testimonial-two__client-sub-title">CO Founder</p>
                                            </div>
                                        </div>
                                        <p class="testimonial-two__text-2">Exercitation ullamco laboris nisi ut aliquip
                                            ex ea ex commodo consequat duis aute aboris nisi ut aliquip irure
                                            reprehederit in voluptate velit esse .</p>
                                        <div class="testimonial-two__quote">
                                            <span class="icon-quotes"></span>
                                        </div>
                                        <div class="testimonial-two__rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Testimonial Two Single End-->
                                <!--Testimonial Two Single Start-->
                                <div class="item">
                                    <div class="testimonial-two__single">
                                        <div class="testimonial-two__client-info">
                                            <div class="testimonial-two__client-img">
                                                <img src="assets/images/testimonial/testimonial-two-client-img-4.jpg"
                                                    alt="">
                                            </div>
                                            <div class="testimonial-two__client-content">
                                                <h4 class="testimonial-two__client-name">Jessica Brown</h4>
                                                <p class="testimonial-two__client-sub-title">CO Founder</p>
                                            </div>
                                        </div>
                                        <p class="testimonial-two__text-2">Exercitation ullamco laboris nisi ut aliquip
                                            ex ea ex commodo consequat duis aute aboris nisi ut aliquip irure
                                            reprehederit in voluptate velit esse .</p>
                                        <div class="testimonial-two__quote">
                                            <span class="icon-quotes"></span>
                                        </div>
                                        <div class="testimonial-two__rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                                <!--Testimonial Two Single End-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Testimonial Two End-->


        <!--Gallery Page Start-->

        <!--Gallery Page Start-->
        <section id="gallery" class="gallery-carousel-page">
            <div class="container">
                
                <div class="section-title text-center">
                    <span class="section-title__tagline">Our work would not be possible without the work of our
                        dedicated volunteers.</span>
                    <h3 class="section-title__title">Our Gallery</h2>
                </div>
                <div class="gallery-carousel thm-owl__carousel owl-theme owl-carousel carousel-dot-style"
                    data-owl-options='{
                    "items": 3,
                    "margin": 30,
                    "smartSpeed": 700,
                    "loop":true,
                    "autoplay": 6000,
                    "nav":false,
                    "dots":true,
                    "navText": ["<span class=\"fa fa-angle-left\"></span>","<span class=\"fa fa-angle-right\"></span>"],
                    "responsive":{
                        "0":{
                            "items":1
                        },
                        "768":{
                            "items":2
                        },
                        "992":{
                            "items": 3
                        }
                    }
                }'>


                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/1.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/1.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->
                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/2.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/2.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->
                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/3.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/3.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->
                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/4.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/4.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->
                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/1.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/1.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->

                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/2.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/2.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->
                    <!--Gallery Page Single Start-->
                    <div class="item">
                        <div class="gallery-page__single">
                            <div class="gallery-page__img">
                                <img src="assets/images/gallery/1.png" alt="">
                                <div class="gallery-page__icon">
                                    <a class="img-popup" href="assets/images/gallery/1.png"><span
                                            class="icon-plus-symbol"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery Page Single End-->
                </div>
            </div>
        </section>
        <!--Gallery Page End-->

        <!--Gallery Page End-->


        <!--Contact One Start-->
        <section id="contact" class="contact-one">
            <div class="container">
                <div class="section-title text-center">
                    <span class="section-title__tagline">Contact with us</span>
                    <h2 class="section-title__title">Feel free to write us <br> anytime</h2>
                </div>
                <div class="contact-one__form-box">
                    <form action="assets/inc/sendemail.php" class="contact-one__form contact-form-validated"
                        novalidate="novalidate">
                        <div class="row">
                            <div class="col-xl-6">
                                <div class="contact-form__input-box">
                                    <input type="text" placeholder="Your Name" name="name">
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="contact-form__input-box">
                                    <input type="email" placeholder="Email Address" name="email">
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="contact-form__input-box">
                                    <input type="text" placeholder="Phone" name="phone">
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="contact-form__input-box">
                                    <input type="text" placeholder="Subject" name="subject">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="contact-form__input-box text-message-box">
                                    <textarea name="message" placeholder="Write a Message"></textarea>
                                </div>
                                <div class="contact-form__btn-box">
                                    <button type="submit" class="thm-btn contact-form__btn">Send a Message</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <!--Contact One End-->

        <!--Address Start-->
        <section class="address">
            <div class="container">
                <div class="row">
                    <!--Address Single Start-->
                    <div class="col-xl-4 col-lg-4">
                        <div class="address__single">
                            <div class="address__title-box">
                                <h4 class="address__title">About</h4>
                                <div class="address__icon">
                                    <span class="icon-entrepreneur-1"></span>
                                </div>
                            </div>
                            <p class="address__text">Morbi ut tellus ac leo mol <br> stie luctus nec vehicula sed <br>
                                justo
                                onecpat ras lorem.</p>
                        </div>
                    </div>
                    <!--Address Single End-->
                    <!--Address Single Start-->
                    <div class="col-xl-4 col-lg-4">
                        <div class="address__single">
                            <div class="address__title-box">
                                <h4 class="address__title">Address</h4>
                                <div class="address__icon">
                                    <span class="icon-location"></span>
                                </div>
                            </div>
                            <p class="address__text">68 Road Broklyn Street. <br> New York. United States of <br>
                                America</p>
                        </div>
                    </div>
                    <!--Address Single End-->
                    <!--Address Single Start-->
                    <div class="col-xl-4 col-lg-4">
                        <div class="address__single">
                            <div class="address__title-box">
                                <h4 class="address__title">Contact</h4>
                                <div class="address__icon">
                                    <span class="icon-contact"></span>
                                </div>
                            </div>
                            <p class="address__text">
                                <a href="tel:9288006780" class="address__number">+92 ( 8800 ) - 6780</a>
                                <a href="mailto:needhelp@qrowd.com" class="address__email">needhelp@qrowd.com</a>
                                <a href="mailto:info@qrowd.com" class="address__email">info@qrowd.com</a>
                            </p>
                        </div>
                    </div>
                    <!--Address Single End-->
                </div>
            </div>
        </section>
        <!--Address End-->

        <!--Google Map Start-->
        <section class="google-map">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.753041141002!2d-118.80123790098536!3d34.152323469614075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80e82469c2162619%3A0xba03efb7998eef6d!2sCostco+Wholesale!5e0!3m2!1sbn!2sbd!4v1562518641290!5m2!1sbn!2sbd"
                class="google-map__one" allowfullscreen=""></iframe>

        </section>
        <!--Google Map End-->
        <!--Events One Start-->
        <!-- <section class="events-one" id="events">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="events-one__left">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">Upcoming events</span>
                                <h2 class="section-title__title">Ready to Join our New Upcoming Events</h2>
                            </div>
                            <p class="events-one__text">Every man must decide whether he will walk in the light
                                of creative
                                altruism or in the darkness of eritdestructive selfishness. Ut porttitor et lectus ut
                                tempus. Aliquam lacinia justo.</p>
                            <a href="events.html" class="thm-btn events-one__btn">View All Events</a>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="events-one__right">
                            <ul class="list-unstyled events-one__list">
                                <li>
                                    <div class="events-one__img">
                                        <img src="assets/images/events/events-1-1.jpg" alt="">
                                        <div class="events-one__date">
                                            <p>23 May, 2022</p>
                                        </div>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><i class="fas fa-clock"></i>8:00pm</li>
                                            <li><i class="fas fa-map-marker-alt"></i>New York</li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="event-details.html">New small businesses
                                                <br> saturday workshop</a></h3>
                                        <div class="events-one__read-more">
                                            <a href="event-details.html"> <span class="icon-right-arrow"></span> Read
                                                more</a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="events-one__img">
                                        <img src="assets/images/events/events-1-2.jpg" alt="">
                                        <div class="events-one__date">
                                            <p>23 May, 2022</p>
                                        </div>
                                    </div>
                                    <div class="events-one__content">
                                        <ul class="list-unstyled events-one__meta">
                                            <li><i class="fas fa-clock"></i>8:00pm</li>
                                            <li><i class="fas fa-map-marker-alt"></i>New York</li>
                                        </ul>
                                        <h3 class="events-one__title"><a href="event-details.html">New small businesses
                                                <br> saturday workshop</a></h3>
                                        <div class="events-one__read-more">
                                            <a href="event-details.html"> <span class="icon-right-arrow"></span> Read
                                                more</a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!--Events One End-->




<?php include "includes/footer.php" ?>