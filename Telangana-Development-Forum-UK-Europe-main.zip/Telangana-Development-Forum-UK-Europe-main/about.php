<?php include "includes/header.php" ?>




        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/1.svg)">
            </div>
            <div class="page-header-shape-1 float-bob-x">
                <img src="assets/images/shapes/page-header-shape-1.png" alt="">
            </div>
            <div class="page-header-shape-2 float-bob-y">
                <img src="assets/images/shapes/page-header-shape-2.png" alt="">
            </div>
            <div class="page-header-shape-3 float-bob-x">
                <img src="assets/images/shapes/page-header-shape-3.png" alt="">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><span>/</span></li>
                        <li>About</li>
                    </ul>
                    <h2>About Us</h2>
                </div>
            </div>
        </section>
        <!--Page Header End-->







        
        <!--About Two Start-->
        <section class="about-two">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="about-two__left">
                            <div class="section-title text-left">
                                <span class="section-title__tagline">About</span>
                                <h2 class="section-title__title">Telangana Development
                                Forum UK Europe</h2>
                            </div>
                            <p class="about-two__text-1">About Telangana–
                            The 29th state of Indian union.</p>
                            <p class="about-two__text-2">There are many variations of passages of Lorem Ipsum available,
                                but the majority have suffered alteration in some form, by injected humour, or
                                randomised words which don't look.</p>
                            <div class="about-two__progress">
                                <div class="about-two__progress-single">
                                    <h4 class="about-two__progress-title">Crowdfunding</h4>
                                    <div class="bar">
                                        <div class="bar-inner count-bar" data-percent="70%">
                                            <div class="count-text">70%</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <ul class="welcome-one__points list-unstyled py-5">
                                <li>
                                    <div class="icon">
                                        <span class="icon-success"></span>
                                    </div>
                                    <div class="content">
                                        <h3>Highest Success Rates</h3>
                                        <p>Magna aliqa enim sed ipsum nisi ainy veniam quis</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <span class="icon-money-bag"></span>
                                    </div>
                                    <div class="content">
                                        <h3>Millions in Funding</h3>
                                        <p>Lorem ipsum dolor sit ametys consectet elit</p>
                                    </div>
                                </li>
                            </ul>
                           
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="about-two__right">
                            <div class="about-two__img-box">
                                <div class="about-two__img">
                                    <img src="assets/images/landingpage/about-1.svg" alt="">
                                </div>
                                <div class="about-two__img-two">
                                    <img src="assets/images/landingpage/about-2.svg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--About Two End-->



         <!--Brand One Start-->
         <section class="brand-one">
            <div class="container">
                <div class="brand-one__title"></div>
                <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100,
                "slidesPerView": 5,
                "loop": true,
                "navigation": {
                    "nextEl": "#brand-one__swiper-button-next",
                    "prevEl": "#brand-one__swiper-button-prev"
                },
                "autoplay": { "delay": 5000 },
                "breakpoints": {
                    "0": {
                        "spaceBetween": 30,
                        "slidesPerView": 2
                    },
                    "375": {
                        "spaceBetween": 30,
                        "slidesPerView": 2
                    },
                    "575": {
                        "spaceBetween": 30,
                        "slidesPerView": 3
                    },
                    "767": {
                        "spaceBetween": 50,
                        "slidesPerView": 4
                    },
                    "991": {
                        "spaceBetween": 50,
                        "slidesPerView": 5
                    },
                    "1199": {
                        "spaceBetween": 100,
                        "slidesPerView": 5
                    }
                }}'>
                    <div class="swiper-wrapper">
                    <div class="swiper-slide">
                            <img src="assets/images/brand/1.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/2.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/3.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/4.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/5.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/1.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/6.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/7.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/2.png" alt="">
                        </div><!-- /.swiper-slide -->
                        <div class="swiper-slide">
                            <img src="assets/images/brand/3.png" alt="">
                        </div><!-- /.swiper-slide -->                    </div>
                </div>
                <!-- If we need navigation buttons -->
                <div class="brand-one__nav">
                    <div class="swiper-button-prev" id="brand-one__swiper-button-next">
                        <i class="fas fa-angle-left"></i>
                    </div>
                    <div class="swiper-button-next" id="brand-one__swiper-button-prev">
                        <i class="fas fa-angle-right"></i>
                    </div>
                </div>
            </div>
        </section>
        <!--Brand One End-->








<?php include "includes/footer.php" ?>