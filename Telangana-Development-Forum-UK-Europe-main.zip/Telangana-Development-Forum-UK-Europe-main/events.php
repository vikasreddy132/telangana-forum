<?php include "includes/header.php" ?>




        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/1.svg)">
            </div>
            <div class="page-header-shape-1 float-bob-x">
                <img src="assets/images/shapes/page-header-shape-1.png" alt="">
            </div>
            <div class="page-header-shape-2 float-bob-y">
                <img src="assets/images/shapes/page-header-shape-2.png" alt="">
            </div>
            <div class="page-header-shape-3 float-bob-x">
                <img src="assets/images/shapes/page-header-shape-3.png" alt="">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><span>/</span></li>
                        <li>Events</li>
                    </ul>
                    <h2>Events List</h2>
                </div>
            </div>
        </section>
        <!--Page Header End-->

     <!--Events List Start-->
     <section class="events-list">
            <div class="container">
                <div class="events-list__inner">
                    <!--Events List Single Start-->
                    <div class="events-list__single">
                        <div class="events-list__left">
                            <div class="events-list__img">
                                <img src="assets/images/events/events-list-img-1-1.jpeg" alt="">
                                <div class="events-list__date">
                                    <p>7 Sep, 2024</p>
                                </div>
                            </div>
                            <div class="events-list__content">
                                <ul class="list-unstyled events-list__meta">
                                    <li><i class="fas fa-clock"></i>7 Sep  7:00 pm</li>
                                    <li><i class="fas fa-map-marker-alt"></i>United Kingdom</li>
                                </ul>
                                <h3 class="events-list__title"><a href="event-details.php">Vinayaka Chavathi Usthavaluu</a></h3>
                                <p class="events-list__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s</p>
                            </div>
                        </div>
                        <div class="events-list__btn-box">
                            <a href="event-details.php" class="thm-btn events-list__btn">Know More</a>
                        </div>
                    </div>
                    <!--Events List Single End-->
                    <!--Events List Single Start-->
                    <div class="events-list__single">
                        <div class="events-list__left">
                            <div class="events-list__img">
                                <img src="assets/images/events/events-list-img-1-1.jpeg" alt="">
                                <div class="events-list__date">
                                    <p>7 Sep, 2024</p>
                                </div>
                            </div>
                            <div class="events-list__content">
                                <ul class="list-unstyled events-list__meta">
                                    <li><i class="fas fa-clock"></i>7 Sep  7:00 pm</li>
                                    <li><i class="fas fa-map-marker-alt"></i>United Kingdom</li>
                                </ul>
                                <h3 class="events-list__title"><a href="event-details.php">Vinayaka Chavathi Usthavaluu</a></h3>
                                <p class="events-list__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s</p>
                            </div>
                        </div>
                        <div class="events-list__btn-box">
                            <a href="event-details.php" class="thm-btn events-list__btn">Know More</a>
                        </div>
                    </div>
                    <!--Events List Single End-->
                    <!--Events List Single Start-->
                    <div class="events-list__single">
                        <div class="events-list__left">
                            <div class="events-list__img">
                                <img src="assets/images/events/events-list-img-1-1.jpeg" alt="">
                                <div class="events-list__date">
                                    <p>7 Sep, 2024</p>
                                </div>
                            </div>
                            <div class="events-list__content">
                                <ul class="list-unstyled events-list__meta">
                                    <li><i class="fas fa-clock"></i>7 Sep  7:00 pm</li>
                                    <li><i class="fas fa-map-marker-alt"></i>United Kingdom</li>
                                </ul>
                                <h3 class="events-list__title"><a href="event-details.php">Vinayaka Chavathi Usthavaluu</a></h3>
                                <p class="events-list__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s</p>
                            </div>
                        </div>
                        <div class="events-list__btn-box">
                            <a href="event-details.php" class="thm-btn events-list__btn">Know More</a>
                        </div>
                    </div>
                    <!--Events List Single End-->
                    <!--Events List Single Start-->
                    <div class="events-list__single">
                        <div class="events-list__left">
                            <div class="events-list__img">
                                <img src="assets/images/events/events-list-img-1-1.jpeg" alt="">
                                <div class="events-list__date">
                                    <p>7 Sep, 2024</p>
                                </div>
                            </div>
                            <div class="events-list__content">
                                <ul class="list-unstyled events-list__meta">
                                    <li><i class="fas fa-clock"></i>7 Sep  7:00 pm</li>
                                    <li><i class="fas fa-map-marker-alt"></i>United Kingdom</li>
                                </ul>
                                <h3 class="events-list__title"><a href="event-details.php">Vinayaka Chavathi Usthavaluu</a></h3>
                                <p class="events-list__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s</p>
                            </div>
                        </div>
                        <div class="events-list__btn-box">
                            <a href="event-details.php" class="thm-btn events-list__btn">Know More</a>
                        </div>
                    </div>
                    <!--Events List Single End-->
                    <!--Events List Single Start-->
                    <div class="events-list__single">
                        <div class="events-list__left">
                            <div class="events-list__img">
                                <img src="assets/images/events/events-list-img-1-1.jpeg" alt="">
                                <div class="events-list__date">
                                    <p>7 Sep, 2024</p>
                                </div>
                            </div>
                            <div class="events-list__content">
                                <ul class="list-unstyled events-list__meta">
                                    <li><i class="fas fa-clock"></i>7 Sep  7:00 pm</li>
                                    <li><i class="fas fa-map-marker-alt"></i>United Kingdom</li>
                                </ul>
                                <h3 class="events-list__title"><a href="event-details.php">Vinayaka Chavathi Usthavaluu</a></h3>
                                <p class="events-list__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s</p>
                            </div>
                        </div>
                        <div class="events-list__btn-box">
                            <a href="event-details.php" class="thm-btn events-list__btn">Know More</a>
                        </div>
                    </div>
                    <!--Events List Single End-->
                    <!--Events List Single Start-->
                    <div class="events-list__single">
                        <div class="events-list__left">
                            <div class="events-list__img">
                                <img src="assets/images/events/events-list-img-1-1.jpeg" alt="">
                                <div class="events-list__date">
                                    <p>7 Sep, 2024</p>
                                </div>
                            </div>
                            <div class="events-list__content">
                                <ul class="list-unstyled events-list__meta">
                                    <li><i class="fas fa-clock"></i>7 Sep  7:00 pm</li>
                                    <li><i class="fas fa-map-marker-alt"></i>United Kingdom</li>
                                </ul>
                                <h3 class="events-list__title"><a href="event-details.php">Vinayaka Chavathi Usthavaluu</a></h3>
                                <p class="events-list__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s</p>
                            </div>
                        </div>
                        <div class="events-list__btn-box">
                            <a href="event-details.php" class="thm-btn events-list__btn">Know More</a>
                        </div>
                    </div>
                    <!--Events List Single End-->
                </div>
            </div>
        </section>
        <!--Events List End-->










<?php include "includes/footer.php" ?>        

