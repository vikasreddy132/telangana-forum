<?php include "includes/header.php" ?>




        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header-bg" style="background-image: url(assets/images/backgrounds/1.svg)">
            </div>
            <div class="page-header-shape-1 float-bob-x">
                <img src="assets/images/shapes/page-header-shape-1.png" alt="">
            </div>
            <div class="page-header-shape-2 float-bob-y">
                <img src="assets/images/shapes/page-header-shape-2.png" alt="">
            </div>
            <div class="page-header-shape-3 float-bob-x">
                <img src="assets/images/shapes/page-header-shape-3.png" alt="">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <ul class="thm-breadcrumb list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><span>/</span></li>
                        <li>Events</li>
                    </ul>
                    <h2>Event Details</h2>
                </div>
            </div>
        </section>
        <!--Page Header End-->



          <!--Event Details Start-->
          <section class="event-details">
            <div class="container">
                <div class="row">
                    <div class="event-details__img">
                        <img src="assets/images/events/events-list-img-1-1.jpeg" class="w-100"  >
                        <div class="event-details__date">
                            <p>23 May, 2022</p>
                        </div>
                    </div>
                </div>
                <div class="event-details__bottom">
                    <div class="row">
                        <div class="col-xl-8 col-lg-7">
                            <div class="event-details__left">
                                <div class="event-details__content-one">
                                    <h3 class="event-details__content-one-title">Vinayaka Chavathi Usthavaluu
                                    </h3>
                                    <p class="event-details__content-one-text-1">There are many variations of passages
                                        of Lorem Ipsum available, but the majority have suffered alteration in some
                                        form, by injected humour, or randomised words which don't look even slightly
                                        believable. If you are going to use a passage of Lorem Ipsum, you need to be
                                        sure there isn't anything embarrassing hidden in the middle of text.</p>
                                    <p class="event-details__content-one-text-2">Biophilia is the idea that humans
                                        possess an innate tendency to seek connections with nature. The term translates
                                    </p>
                                    <p class="event-details__content-one-text-3">Lorem Ipsum is simply dummy text of the
                                        printing and typesetting industry. Lorem Ipsum has been the industry's standard
                                        dummy text ever since the 1500s, when an unknown printer took a galley of type
                                        and scrambled it to make a type specimen book. It has survived not only five
                                        centuries, but also the leap into electronic typesetting, remaining essentially
                                        unchanged. </p>
                                </div>
                                <div class="event-details__content-two">
                                    <h3 class="event-details__content-two-title">Event Requirements</h3>
                                    <p class="event-details__content-two-1">Lorem Ipsum is simply dummy text of the
                                        printing and typesetting industry. Lorem Ipsum has been the industry's standard
                                        dummy text ever since the 1500s, when an unknown printer took a galley of type
                                        and scrambled it to make a type specimen book. It has survived not only five
                                        centuries.</p>
                                    <p class="event-details__content-two-2">It was popularised in the 1960s with the
                                        release of Letraset sheets containing Lorem Ipsum passages, and more recently
                                        with desktop publishing software like Aldus PageMaker including versions of
                                        Lorem Ipsum ley of type and scrambled it to make a type specimen book. </p>
                                    <div class="event-details__btn-box">
                                        <a href="event.details.html" class="thm-btn event-details__btn">Join Event</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5">
                            <div class="event-details__sidebar">
                                <div class="event-details__details-box">
                                    <h5 class="event-details__details-box-title">Event Details</h5>
                                    <ul class="list-unstyled event-details__details-box-list">
                                        <li>
                                            <div class="left">
                                                <p>Starting Time:</p>
                                            </div>
                                            <div class="right">
                                                <p>7:00pM to 10:00PM</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="left">
                                                <p>Date:</p>
                                            </div>
                                            <div class="right">
                                                <p>7 Sep, 2024</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="left">
                                                <p>Categroy:</p>
                                            </div>
                                            <div class="right">
                                                <p>Festivel</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="left">
                                                <p>Phone:</p>
                                            </div>
                                            <div class="right">
                                                <p><a href="tel:926668880000">92 666 888 0000</a></p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="left">
                                                <p>Website:</p>
                                            </div>
                                            <div class="right">
                                                <p><a class="clr-primary" href="mailto:Info@event.com">Info@event.com</a></p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="left">
                                                <p>Location:</p>
                                            </div>
                                            <div class="right">
                                                <p class="clr-base">London Sri Mahalakshmi Temple
                                                241, High Street North, London, E12 6SJ</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="event-details__map">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.753041141002!2d-118.80123790098536!3d34.152323469614075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80e82469c2162619%3A0xba03efb7998eef6d!2sCostco+Wholesale!5e0!3m2!1sbn!2sbd!4v1562518641290!5m2!1sbn!2sbd" class="event-details__map-one" allowfullscreen=""></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Event Details End-->





        <?php include "includes/footer.php" ?>